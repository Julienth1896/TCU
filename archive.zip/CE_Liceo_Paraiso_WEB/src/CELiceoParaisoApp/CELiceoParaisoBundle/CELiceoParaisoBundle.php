<?php

namespace CELiceoParaisoApp\CELiceoParaisoBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CELiceoParaisoBundle extends Bundle
{
}
